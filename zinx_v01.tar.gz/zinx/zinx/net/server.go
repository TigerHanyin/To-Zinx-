package net

import (
	"zinx/zinx/ziface"
	"fmt"
	"net"
)

/*
server模块的实现层
*/
type Server struct {
	//服务器IP
	IpVersion string
	IP        string
	//服务器端口
	Port int
	//服务器名称
	Name string
}

//初始化的New方法
func NewServer(name string)ziface.IServer {
	s := &Server{
		Name:      name,
		Port:      8999,
		IP:        "0.0.0.0",
		IpVersion: "tcp4",
	}
	return s
}

//启动服务器
func (s *Server) Start() {
	fmt.Printf("【start】Server Listening at IP:%s,Port:%d",s.IpVersion,s.Port)
	//1 创建套接字  ：得到一个TCP的addr
	addr,err:=net.ResolveTCPAddr(s.IpVersion,fmt.Sprintf("%s:%d",s.IP,s.Port))
	if err!=nil{
		fmt.Println("resolve tcp addr erro:",err)
		return
	}
	//2 监听服务器地址
	listenner,err:=net.ListenTCP(s.IpVersion,addr)
	if err!=nil{
		fmt.Println("listen",s.IpVersion,"err",err)
		return
	}
	//3 阻塞等待客户端发送请求，
	go func() {
		for {
			conn,err:=listenner.Accept()
			if err!=nil{
				fmt.Println("Accept err:",err)
				continue
			}
			//此时conn就已经和对端客户端连接
			go func() {
				for{
					buf:=make([]byte,512)
					cnt,err:=conn.Read(buf)
					if err!=nil{
						fmt.Println("recv buf err:",err)
						break
					}
					fmt.Printf("recv client buf %s,cnt=%d\n",buf,cnt)
					//回显功能 （业务）
					if _,err:=conn.Write(buf[:cnt]);err!=nil{
						fmt.Println("write back buf err:",err)
						continue
					}
				}
			}()
		}
	}()
}
func (s *Server) Stop() {
	//TODO 将一些服务器资源进行回收

}
func (s *Server) Serve() {
	//启动server的监听功能
	s.Start()
	//TODO  做一些其他的扩展
	//阻塞//告诉CPU不再需要处理的，节省cpu资源
	select {
	}

}
