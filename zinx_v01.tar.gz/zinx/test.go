package main

import "fmt"

type Card interface {
	Display()
}
type Memory interface {
	Storage()
}
type Computer struct {
	card Card
	mem Memory
}
func NewComputer (card Card,mem Memory)*Computer{
	return &Computer{
		card:card,
		mem:mem,
	}
}
func (this *Computer)DoWork(){
	this.card.Display()
	this.mem.Storage()
}

type IntelCard struct {
		Card
}
func(this *IntelCard)Display(){
	fmt.Println("interl is storaging")
}
type NavCard struct {
	Card
}
func(this *NavCard)Display(){
	fmt.Println("Nva is storaging")
}
func main(){
	com1:=NewComputer(&IntelCard{})
	com1.DoWork()
	com2:=NewComputer(&NavCard{})
	com2.DoWork()
}